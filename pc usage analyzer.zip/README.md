# PC Usage Analyzer
An app to track time spent on each app with ability to export data well for analysis. 

![](./screenshots/start.jpg)

## Start time
this is when tracking the app usage starts

## End time
this is when tracking the app usage ends

## real duration
this is the actual time spent on the app, this may not be end time - start time, coz you might have used some other app in between. This is calculated by the app.

## Title
this is the title of the app, or the tab and the window you are using. 

## Todo
- [ ] Make a nice gui hopefully visible on browser. maybe with django. 
- [ ] Add analysis, charts and graphs in a new tab on that ui interface in browser. a dashboard. 